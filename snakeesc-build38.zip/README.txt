ESCAPE THE SNAKE — BUILD 38

Restores Build 33 snake artwork, dimensions and spacing. Keeps Build 37 menus.

WEBSITE: Replace your existing index.html with standalone-index.html (rename it
index.html). It embeds the assets and original audio.

APP / DESKTOP PROJECT: Use game/ as the web content directory. Its index.html
loads local styles, scripts, images, fonts and original audio from subfolders.
Preserve the directory structure. No bundler or package installation required.
From this directory run: python3 -m http.server 8000
Then open http://localhost:8000/game/ to test locally.

art-source/ contains named art assets, including alternate trial sprites.
The runtime uses only the assets referenced by game/; asset-manifest.json lists
extracted files with MIME types. Do not replace the active sprites with trial art.

This is a portable HTML game source package, not an App Store or Steam binary.
A platform wrapper, app identity/icons, signing and store configuration are still
needed. No store submission or native build is included.

The public leaderboard and relevant profile metadata require internet access.
Their existing service code is not included. Scores/player identity use browser
storage; a new wrapper will have its own storage and may create a new identity.
Original audio is included; audio playback must be tested inside the chosen wrapper.

Validation: script syntax and local asset references checked. Native packaging,
real-device input/audio, and live score submission have not been tested here.
This package reflects the game version worked on in this conversation, without
merging subsequent changes from the live repository.
